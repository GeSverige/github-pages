# GE Sverige landningssida

Detta repo innehåller en enkel HTML-sida där besökare väljer sin förening.